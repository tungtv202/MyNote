---
title: Install & Config Note
date: 2020-04-01 18:00:26
tags:
    - note
category: 
    - install_guide
---

- Setup Selenium ChromeDriver trên ubuntu   
https://tecadmin.net/setup-selenium-chromedriver-on-ubuntu/
- Setup OpenVPN on linux    
https://support.hidemyass.com/hc/en-us/articles/202721546-OpenVPN-via-terminal-using-openvpn-binary-the-manual-way-
- Install PostgreSQL 12 on linux    
https://computingforgeeks.com/install-postgresql-12-on-ubuntu/
- [Easy Way to Install and Configure OpenVPN Server on Ubuntu 18.04 / Ubuntu 16.04](https://computingforgeeks.com/easy-way-to-install-and-configure-openvpn-server-on-ubuntu-18-04-ubuntu-16-04/)