---
title: AWS - IAM 
date: 2020-01-30 18:00:26
updated: 2020-01-30 18:00:26
tags:
    - aws
    - iam
    - policy 
category: 
    - aws
---

- add user
![AddUser](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Account.png)
![Group1](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Group1.png)
![Group2](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Group2.png)
![Group3](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Group3.png)
![Policy1](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Policy1.png)
![Policy2](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Policy2.png)
![Policy3](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Policy3.png)
![Policy4](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Policy4.png)
![Policy5](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/aws/iam/Policy5.png)
