---
title: AWS - Design for organizational
date: 2020-01-25 18:00:26
tags:
    - aws
category: 
    - aws
---

## 1. Multi-Account Strategy
- Các khía cạnh cần quan tâm:
    - Identity Account Architecture
    - Logging Account Architecture
    - Publishing Account Structure
    - Billing Structure
