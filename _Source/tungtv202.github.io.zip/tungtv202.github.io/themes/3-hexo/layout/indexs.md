# Why Blog
> i want to save all knowledge and experience

> i hope that one day, this will help me meet someone who shares similarities

![](https://tungexplorer.s3-ap-southeast-1.amazonaws.com/background_blog.jpg)
